var localeStr = {
    id: 'en',
    manifest: {
        name: 'J-Weather',
        description: 'Client extension for JavaWeather server'
    },
    options: {
        server: 'Server',
        provider: 'Provider',
        location: 'City/Town',
        save: 'Apply'
    },
    popup: {
        wind: 'Wind',
        humidity: 'Hum.',
        error: 'Could not connect to server'
    }
}