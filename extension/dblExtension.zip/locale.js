var localeStr;
(function(){
    function msg(name) { return chrome.i18n.getMessage(name) }
    
    localeStr = {
        id: msg('id'),
        manifest: {
            name: msg('name'),
            description: msg('description')
        },
        options: {
            server: msg('options_server'),
            provider: msg('options_provider'),
            location: msg('options_location'),
            save: msg('options_save')
        },
        popup: {
            wind: msg('popup_wind'),
            humidity: msg('popup_humidity'),
            error: msg('popup_error')
        }
    }
})();