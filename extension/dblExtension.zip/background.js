document.title = localeStr.manifest.name;

var weatherData;

var defaults = {
    server: "http://localhost:7777/",
    provider: "google",
    location: "Kyyiv"
}
for(var setting in defaults) if(!localStorage[setting]) localStorage[setting] = defaults[setting];

function ajaxCall(URL, callback) {
    var ajax = new XMLHttpRequest;
    if(callback) ajax.onreadystatechange = function() { if(ajax.readyState == 4) callback(ajax.responseText) };
    ajax.open('GET', URL, !!callback);
    ajax.send();
    return ajax;
}

function preloadImage(url) { if(url) new Image().src = url }
function preprocessWeather(weatherData) { preloadImage(weatherData.iconUrl) }

if(window.opera) {
    var button = opera.contexts.toolbar.createItem({
        title: localeStr.manifest.name,
        icon: 'icon18.png',
        popup: {
            href: 'popup.html',
            width: 270
        },
        badge: {
            display: 'none',
            color: 'white',
            backgroundColor: 'red'
        }
    });
    var badge = button.badge;
        
    opera.contexts.toolbar.addItem(button);
}

var timerId;
var getWeather = function() {
    if(timerId) {
        clearTimeout(timerId);
        timerId = null;
    }
    ajaxCall(localStorage.server + 'server/' + localStorage.provider + '/location/' + localStorage.location + '/lang/' + localeStr.id + '/', function(data) {
        try {
            weatherData = JSON.parse(data);
            if(weatherData.temperature > 0) weatherData.temperature = '+' + weatherData.temperature;
            if(!(weatherData.forecast instanceof Array)) weatherData.forecast = [];
            preprocessWeather(weatherData);
            weatherData.forecast.forEach(preprocessWeather);
        } catch(e) {
            weatherData = null;
        }
        if(window.opera) {
            if(weatherData && weatherData.temperature) {
                badge.textContent = weatherData.temperature;
                badge.display = 'block';
            } else {
                badge.display = 'none';
            }
        }
        timerId = setTimeout(getWeather, weatherData ? 60000 : 1000);
    });
}

getWeather();